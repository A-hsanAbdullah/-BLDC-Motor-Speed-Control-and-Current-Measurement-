#include "TM4C123.h"                    // Include device-specific header file for Tiva C Series
#include <stdio.h>
#include <stdint.h>

//--------------------------------------------------------------------------------------------
// LCD Configuration
#define LCD GPIOB      // Define LCD port as GPIOB
#define RS 0x01        // Register Select -> PB0
#define RW 0x02        // Read/Write Select -> PB1
#define EN 0x04        // Enable -> PB2

// Global variables
float adc_value_pot, adc_value_current, voltage_pot, voltage_current;  // ADC readings and voltages
volatile uint32_t estimated_rpm = 0;                                   // Estimated RPM from potentiometer
volatile float current_value = 0.0;                                    // Current sensor value
unsigned volatile long j, i;                                           // Loop counters
uint32_t edge_count = 0;                                               // Rising edge count for RPM
volatile uint32_t rpm = 0;                                             // Current RPM value
uint32_t previous_rpm = 0;                                             // Previous RPM value
uint32_t edge_in_period = 0;                                           // Edges in a time period
uint32_t time_measurement = 0;                                         // Time measurement for calculations
char buffer[10];                                                       // Buffer for integer/string conversions
char buffer_2[20];                                                     // Extended buffer
volatile uint32_t duty;                                                // PWM duty cycle



// UART Function to send a string
void UART0_SendString(char *str)
{
    while (*str)                                   // Loop through string until null terminator
    {
        while ((UART0->FR & 0x20) != 0);          // Wait until UART is not busy
        UART0->DR = *str;                         // Transmit character
        str++;                                    // Increment string pointer
    }
}

// Millisecond delay function
void delayMs(int n)
{
    volatile int i, j;                            // Declare volatile loop variables
    for (i = 0; i < n; i++)                       // Loop for each millisecond
        for (j = 0; j < 3180; j++)                // Inner loop for ~1 ms delay
        {}
}

// Microsecond delay function
void delayUs(int n)
{
    volatile int i, j;                            // Declare volatile loop variables
    for (i = 0; i < n; i++)                       // Loop for each microsecond
        for (j = 0; j < 3; j++)                   // Inner loop for ~1 �s delay
        {}
}

// Send data to LCD in 4-bit mode
void LCD_Write4bits(unsigned char data, unsigned char control)
{
    data &= 0xF0;                                 // Mask lower nibble
    control &= 0x0F;                              // Mask upper nibble
    LCD->DATA = data | control;                   // Combine data and control bits
    LCD->DATA = data | control | EN;              // Set EN to send data
    delayUs(0);                                   // Short delay for EN pulse
    LCD->DATA = data | control;                   // Clear EN
    LCD->DATA = 0;                                // Reset LCD data
}

// Write a character to the LCD
void LCD4bits_Data(unsigned char data)
{
    LCD_Write4bits(data & 0xF0, RS);              // Send upper nibble
    LCD_Write4bits(data << 4, RS);                // Send lower nibble
    delayUs(40);                                  // Delay for LCD processing
}

// Convert a float to a string
void floatToString(float num)
{
    int integer_part = (int)num;                  // Extract integer part
    int decimal_part = (int)((num - integer_part) * 100);  // Extract 2 decimal places
    int index = 0;                                // Initialize buffer index

    if (integer_part == 0)                        // Handle zero integer part
        buffer[index++] = '0';
    else                                          // Convert integer to string
    {
        int temp = integer_part;
        while (temp > 0)
        {
            buffer[index++] = '0' + (temp % 10);  // Extract digits in reverse order
            temp /= 10;
        }
        for (int i = 0; i < index / 2; i++)       // Reverse digits for correct order
        {
            char temp_char = buffer[i];
            buffer[i] = buffer[index - i - 1];
            buffer[index - i - 1] = temp_char;
        }
    }
    buffer[index++] = '.';                        // Add decimal point
    buffer[index++] = '0' + (decimal_part / 10);  // Add first decimal digit
    buffer[index++] = '0' + (decimal_part % 10);  // Add second decimal digit
    buffer[index] = '\0';                         // Null-terminate string
}

// Convert an integer to a string
void intToString(int num)
{
    int index = 0;                                // Initialize buffer index
    if (num == 0)                                 // Handle zero case
        buffer[index++] = '0';
    while (num > 0)                               // Extract digits
    {
        buffer[index++] = '0' + (num % 10);
        num /= 10;
    }
    buffer[index] = '\0';                         // Null-terminate string
    for (int i = 0; i < index / 2; i++)           // Reverse digits for correct order
    {
        char temp = buffer[i];
        buffer[i] = buffer[index - i - 1];
        buffer[index - i - 1] = temp;
    }
}

// Short delay function based on clock cycles
void clocks_delay(volatile uint32_t clocks)
{
    while (clocks--);                             // Decrement until zero
}

// Function to write a string to the LCD
void LCD_WriteString(char *str)
{
    volatile int i = 0;                           // Volatile loop index
    while (*(str + i) != '\0')                    // Iterate through string
    {
        LCD4bits_Data(*(str + i));                // Write character to LCD
        i++;                                      // Increment index
    }
}

// Command function for LCD
void LCD4bits_Cmd(unsigned char command)
{
    LCD_Write4bits(command & 0xF0, 0);            // Send upper nibble
    LCD_Write4bits(command << 4, 0);              // Send lower nibble
    if (command < 4)
        delayMs(2);                               // Long delay for certain commands
    else
        delayUs(40);                              // Short delay for others
}
// LCD Initialization function

//********************************************
// Function definitions

// This function reads the potentiometer value from ADC0 (PE3) and calculates the duty cycle for PWM control.
// It also estimates the RPM based on the potentiometer value.
void readAndCalculateDutyCycle(void)
{
    // Start ADC conversion for the potentiometer (PE3)
    ADC0->PSSI |= 0x08;   // Trigger ADC conversion on sequencer 3
    while ((ADC0->RIS & 8) == 0);  // Wait for the conversion to complete
    adc_value_pot = ADC0->SSFIFO3;  // Read the ADC value
    ADC0->ISC = 8;  // Clear the interrupt flag

    // Calculate duty cycle as a value between 250 and 500
    voltage_pot = (float)adc_value_pot / 4095.0;   // Normalize the ADC value (12-bit ADC)
    duty = (voltage_pot * 250) + 250;  // Map potentiometer value to duty cycle range
    PWM0->_3_CMPA = duty;   // Set the duty cycle for PWM

    // Estimate RPM based on potentiometer value (scaling factor of 16800)
    estimated_rpm = voltage_pot * 16800;   // Convert potentiometer value to estimated RPM
}

// This function reads current sensor data, performs multiple samples, and calculates the average voltage and current.
void readAndCalculateCurrentSensor(int num_samples)
{
    // Ensure num_samples is at least 1 to avoid division by zero
    if (num_samples < 1)
    {
        num_samples = 1;
    }

    float voltage_sum = 0.0;
    float current_sum = 0.0;

    // Collect 'num_samples' samples from the current sensor
    for (int i = 0; i < num_samples; i++)
    {
        // Start ADC conversion for the current sensor (PE1)
        ADC1->PSSI |= (1 << 3);  // Trigger ADC conversion on sequencer 3
        while ((ADC1->RIS & (1 << 3)) == 0);  // Wait for the conversion to complete
        adc_value_current = ADC1->SSFIFO3;  // Read the ADC value
        ADC1->ISC = (1 << 3);  // Clear the interrupt flag

        // Calculate the voltage from the ADC value and the corresponding current
        float voltage_current_sample = (float)adc_value_current * (4.7 / 4095.0);  // Convert ADC value to voltage
        float current_value_sample = (voltage_current_sample - 3.55) / 0.1;  // Convert voltage to current

        // Ensure current value is non-negative
        if (current_value_sample < 0)
        {
            current_value_sample = -current_value_sample;  // Take the absolute value
        }

        // Accumulate voltage and current values for averaging
        voltage_sum += voltage_current_sample;
        current_sum += current_value_sample;
    }

    // Calculate average voltage and current from the accumulated values
    voltage_current = voltage_sum / num_samples;  // Average voltage
    current_value = current_sum / num_samples;  // Average current
}

// This function displays the calculated RPM and current on the LCD screen.
void displayReadings(void)
{
    LCD4bits_Cmd(0x01);  // Clear the LCD display
    LCD_WriteString("RPM: ");  // Display the "RPM" label
    intToString(rpm);  // Convert RPM value to string and display
    LCD_WriteString(buffer);  // Write RPM value to LCD

    LCD4bits_Cmd(0xC0);  // Move cursor to second line of the LCD
    for (j = 0; j < 500; j++);  // Add delay for readability

    LCD_WriteString("CURRENT: ");  // Display the "CURRENT" label
    floatToString(current_value);  // Convert current value to string and display
    LCD_WriteString(buffer);  // Write current value to LCD
}

// This function sends the RPM, current, and duty cycle values over UART.
void sendReadingsOverUART(void)
{
    char output_string[100];
    // Format the output string with the RPM, current, and duty cycle values
    sprintf(output_string, "RPM: %d, Current: %.2fA , Duty: %d \r\n", rpm, current_value, duty);
    UART0_SendString(output_string);  // Send the formatted string over UART
}

//*************************************************

uint16_t array[2000];
uint16_t index = 0;
// Wide Timer 3A Interrupt Handler
// This interrupt handler calculates RPM based on edge counts measured by the timer.
void WTIMER3A_Handler(void) {
    edge_in_period = edge_count;  // Capture the edge count value
    TIMER3->CTL &= ~(1 << 8);  // Disable the timer for modification
    TIMER3->TBV = 0;  // Reset the timer's value
    TIMER3->CTL |= (1 << 8);  // Enable the timer again
    WTIMER3->ICR = 1;  // Clear the interrupt flag
  
    rpm = edge_in_period * 60;  // Calculate RPM based on edge count (converted to RPM)
	
	
}

// PLL Initialization function to configure and enable the PLL for system clock
void PLL_Init(void)
{
    // 0) Use RCC2 for system clock configuration
    SYSCTL->RCC2 |= 0x80000000;  // Enable RCC2

    // 1) Bypass PLL while initializing
    SYSCTL->RCC2 |= 0x00000800;  // Bypass PLL during initialization

    // 2) Select crystal value and oscillator source (16 MHz crystal)
    SYSCTL->RCC = (SYSCTL->RCC & ~0x000007C0) + 0x00000540;  // Clear XTAL bits and set to 16 MHz crystal
    SYSCTL->RCC2 &= ~0x00000070;  // Configure to use main oscillator

    // 3) Activate PLL by clearing PWRDN (power down)
    SYSCTL->RCC2 &= ~0x00002000;

    // 4) Set system divider for PLL
    SYSCTL->RCC2 |= 0x40000000;  // Enable 400 MHz PLL
    SYSCTL->RCC2 = (SYSCTL->RCC2 & ~0x1FC00000) + (24 << 22);  // Configure the PLL divider for 16 MHz clock

    // 5) Wait for PLL to lock by polling PLLLRIS
    while ((SYSCTL->RIS & 0x00000040) == 0) { }  // Wait until PLL is locked

    // 6) Enable use of PLL by clearing BYPASS
    SYSCTL->RCC2 &= ~0x00000800;  // Disable PLL bypass and enable PLL
}
// Function to initialize PB3 as T3CCP1
void PB3_as_T3CCP1_Init(void) {
    // Enable GPIO Port B clock
    SYSCTL->RCGCGPIO |= (1<<1);
    while((SYSCTL->PRGPIO & (1<<1)) == 0);  // Wait for Port B to be ready
    GPIOB->AFSEL |= (1<<3);  // Enable alternate function for PB3
    GPIOB->PCTL &= ~(0xF << 12);  // Clear PCTL settings for PB3
    GPIOB->PCTL |= (0x7 << 12);  // Set PCTL to T3CCP1 function
    GPIOB->DIR &= ~(1<<3);  // Set PB3 as input
    GPIOB->DEN |= (1<<3);  // Enable digital function for PB3
    GPIOB->PUR |= (1<<3);  // Enable pull-up resistor on PB3
}

// Function to initialize Timer 3B for edge counting
void Timer3B_RisingEdgeEvent_Init(void) {
    // Enable Timer 3 clock
    SYSCTL->RCGCTIMER |= (1<<3);
    while((SYSCTL->PRTIMER & (1<<3)) == 0);  // Wait for Timer 3 to be ready
    TIMER3->CTL &= ~(1<<8);  // Disable Timer 3 before configuration
    TIMER3->CFG = 0x04;  // Set Timer 3 to 16-bit mode
    TIMER3->TBMR |= 0x13;  // Configure Timer 3B for edge counting
    TIMER3->ICR |= (1<<8);  // Clear Timer 3B interrupt flags
    TIMER3->CTL |= (1<<8);  // Enable Timer 3B
}

// Capture current edge count from Timer 3B
uint32_t Timer3B_RisingEdgeEvent_Capture(void) {
    return TIMER3->TBR;  // Return the current edge count
}

// Function to initialize Wide Timer 3A
void wtimer3A_Init(void) {
    // Enable Wide Timer 3 clock
    SYSCTL->RCGCWTIMER |= 1<<3;
    while((SYSCTL->PRWTIMER & 1<<3) == 0);  // Wait for Wide Timer 3 to be ready
    WTIMER3->CTL &= ~(1);  // Disable Wide Timer 3 before configuration
    WTIMER3->CFG = 0x00;  // Set Wide Timer 3 to 32-bit mode
    WTIMER3->TAMR = 2;  // Set Wide Timer 3A to periodic mode
    WTIMER3->TAILR = 16000000 - 1;  // Set the interval to 1 second (16 MHz clock)
    WTIMER3->IMR = 1;  // Enable interrupt for Timer 3A
    WTIMER3->ICR = 1;  // Clear any previous interrupt flags
    WTIMER3->CTL |= 1;  // Enable Wide Timer 3A
    NVIC->ISER[3] = 1<<4;  // Enable interrupt in the NVIC
    NVIC->IP[25] |= (7<<5);  // Set interrupt priority for Timer 3A
}

// Function to initialize PC4 as M0PWM6
void PC4_as_M0PWM6_Init(void) {
    // Enable GPIO Port C clock
    SYSCTL->RCGCGPIO |= 0x04;
    for (j = 0; j < 12; j++);  // Wait for at least 3 clock cycles
    // Enable alternate function for PC4 (M0PWM6)
    GPIOC->AFSEL |= 0x10;
    GPIOC->DEN |= 0x10;  // Enable digital function for PC4
    GPIOC->DIR |= 0x10;  // Set PC4 as output
    GPIOC->PCTL &= 0xFFF0FFFF;  // Clear previous PCTL settings for PC4
    GPIOC->PCTL |= 0x00040000;  // Set PCTL to M0PWM6 function
}

// Function to initialize PWM Module 0 Channel 6
void PWM_Module0_Channel6_Init(void) {
    // Enable PWM Module 0 clock
    SYSCTL->RCGCPWM |= (1 << 0);
    for (j = 0; j < 12; j++);  // Wait for at least 3 clock cycles
    SYSCTL->RCC |=0x001C0000 ;  // Enable clock signal divisor for PWM

    // Disable Generator 3 before performing configurations
    PWM0->_3_CTL = 0x00;
    // Set Load value for 10 kHz frequency
    PWM0->_3_LOAD = 5000;
    // Set Compare Register Value for 50% duty cycle
    PWM0->_3_CMPA = 250;
    // Configure PWM signal generation control
    PWM0->_3_GENA |= 0xC8;
    // Enable Generator 3 counter
    PWM0->_3_CTL |= 0x01;
    // Enable PWM Module 0 Channel 6 Output
    PWM0->ENABLE |= 0x40;
}

// Function to enable ADC
void ADC_Enable(void) {
    // Enable Clock for GPIOE and ADC0/ADC1
    SYSCTL->RCGCGPIO |= (1 << 4);
    SYSCTL->RCGCADC |= 0x03;

    // Configure PE3 (Potentiometer - AIN0)
    GPIOE->AFSEL |= (1 << 3);
    GPIOE->DEN &= ~(1 << 3);
    GPIOE->AMSEL |= (1 << 3);

    // Configure PE1 (Current Sensor - AIN2)
    GPIOE->AFSEL |= (1 << 1);
    GPIOE->DEN &= ~(1 << 1);
    GPIOE->AMSEL |= (1 << 1);

    // Configure ADC0 for PE3 (Potentiometer - AIN0)
    ADC0->ACTSS &= ~(1 << 3);
    ADC0->EMUX &= ~0xF000;
    ADC0->SSMUX3 = 0;
    ADC0->SSCTL3 |= 0x06;
    ADC0->ACTSS |= (1 << 3);

    // Configure ADC1 for PE1 (Current Sensor - AIN2)
    ADC1->ACTSS &= ~(1 << 3);
    ADC1->EMUX &= ~0xF000;
    ADC1->SSMUX3 = 2;
    ADC1->SSCTL3 |= 0x06;
    ADC1->ACTSS |= (1 << 3);
}
// UART0 initialization function for Tx and Rx on Port A (PA0 - Rx, PA1 - Tx)
void UART0_Tx_RX_Init(void) {
	// UART0 -> PA0 (Rx), PA1 (Tx) (Virtual COM Port available on TIVA)
	// If using other UART modules, a TTL or UART to USB converter is needed for PC connection
	
	// Step 1: Enable Clock Gating Control to power on UART0
	SYSCTL->RCGCUART |= 0x01;			// Enable clock on UART0
	for (j = 0; j < 3; j++);		// Wait for at least 3 clock cycles
	
	// Step 2: Ensure UART is disabled before configuration
	UART0->CTL = 0x00;		// Disable UART, Tx, and Rx
	
	// Step 3: Set UART Baud Rate
	UART0->IBRD = 104;		// BRD = UART_Sysclk / (ClkDiv * Baud Rate)
												// BRD = 16,000,000 / (16 * 9600) = 104.166666667
	UART0->FBRD = 11;			// FBRD = BRDF * 64 + 0.5 = 0.166666667 * 64 + 0.5 = 11.1666666667
	
	// Step 4: Configure Line settings for 8-bit word length
	UART0->LCRH |= 0x60;	// 8-bit word length configuration
	
	// Step 5: Select clock source for UART baud rate
	UART0->CC |= 0x05; 		// Use PIOSC (Primary Internal Oscillator) as the clock source
	
	// Step 6: Turn on UART module, Tx, and Rx enable
	UART0->CTL |= 0x301;	// Enable UART, TxEN, and RxEN bits
}

// Initialize PA0 and PA1 as UART0 pins for Tx and Rx functionality
void PA0_1_as_UART_Tx_Rx_Init(void) {
	// Step 1: Enable clock for Port A (for UART Tx/Rx functionality)
	SYSCTL->RCGCGPIO |= 0x01;		// Enable clock for GPIOA
	for (j = 0; j < 3; j++);			// Wait for at least 3 clock cycles
	
	// Step 2: Configure alternate function for Port A (PA0 and PA1)
	// Base address selection for Port A, selecting APB for GPIO
	// Step 3: Enable alternate function on PA0 (Rx) and PA1 (Tx)
	GPIOA->AFSEL |= 0x03;				// Enable alternate function for PA0 and PA1
	
	// Step 4: Enable digital functionality for PA0 and PA1
	GPIOA->DEN |= 0x03; // Enable digital I/O for PA0 and PA1
	
	// Step 5: Set PA0 as Input (Rx) and PA1 as Output (Tx)
	GPIOA->DIR &= ~0x01; // PA0 as Input pin (Rx)
	GPIOA->DIR |= 0x02;  // PA1 as Output pin (Tx)
	
	// Step 6: Configure PA0 and PA1 as UART0 pins based on the datasheet
	GPIOA->PCTL &= 0xFFFFFF00;		// Clear previous configurations for PA0 and PA1
	GPIOA->PCTL |= 0x00000011;		// Set PA0 and PA1 for UART0 functionality
}

// Initialize 4-bit data mode for LCD display (connected to Port B)
void LCD4bits_Init(void) {
    SYSCTL->RCGCGPIO |= 0x02;    // Enable clock for Port B (connected to LCD)
    delayMs(10);                 // Wait for 10ms to allow Port B clock initialization
    LCD->DIR = 0xFF;             // Set all pins on Port B as output pins
    LCD->DEN = 0xFF;             // Enable digital functionality on Port B pins
    LCD4bits_Cmd(0x28);          // Initialize LCD for 2 lines and 5x7 character display (4-bit data mode)
    LCD4bits_Cmd(0x06);          // Set cursor to automatically increment (shift to right)
    LCD4bits_Cmd(0x01);          // Clear the display screen
    LCD4bits_Cmd(0x0C);          // Display ON, with cursor blinking enabled
}
