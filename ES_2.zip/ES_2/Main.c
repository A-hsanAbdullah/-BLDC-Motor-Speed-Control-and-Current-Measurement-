
/* 
-----------------------------------------------------------------------
Semester Project: RPM Calculation using Hall Effect Sensor and Current 
Measurement using ACS712
-----------------------------------------------------------------------
This program calculates the RPM using a Hall effect sensor and the 
current using the ACS712 current sensor. The readings are displayed 
on an LCD and transmitted via UART for monitoring and logging.
-----------------------------------------------------------------------
Written by Ahsan Abdullah (ahsanispro@gmail.com) for Group 2, 
using Keil uVision 5.38.
-----------------------------------------------------------------------
*/
#include "header.h"      // Include for header file
#include <stdio.h>     // Include the standard input-output library
#include <stdint.h>    // Include the standard integer types

int main()
{
    // Initialize the LCD to communicate with the microcontroller
    LCD4bits_Init();                                  // Initialization of LCD (4-bit mode)
    
    // Send commands to the LCD to clear it and position the cursor at the beginning of the first line
    LCD4bits_Cmd(0x01);                              // Clear the display
    LCD4bits_Cmd(0x80);                              // Force the cursor to the beginning of the 1st line
    
    // Delay function to ensure the LCD commands are executed properly
    delayMs(500);

    // Initialize the Phase-Locked Loop (PLL) for high-frequency operation
    PLL_Init();
    
    // Initialize Timer 3 to capture rising edges on PB3 pin
    PB3_as_T3CCP1_Init();
    
    // Initialize Timer 3B to capture rising edge events (for edge counting)
    Timer3B_RisingEdgeEvent_Init();
    
    // Initialize the watch timer for Timer 3A
    wtimer3A_Init();
    
    // Initialize PWM (Pulse Width Modulation) on PC4 pin for motor control or similar applications
    PC4_as_M0PWM6_Init();
    
    // Initialize PWM Module 0 Channel 16
    PWM_Module0_Channel6_Init();
    
    // Enable ADC (Analog-to-Digital Converter) for reading analog sensors
    ADC_Enable();
    
    // Initialize UART0 for serial communication (sending and receiving data)
    UART0_Tx_RX_Init();
    
    // Initialize UART pins PA0 and PA1 for Tx (Transmit) and Rx (Receive)
    PA0_1_as_UART_Tx_Rx_Init();
    
    // Start an infinite loop to continuously check and process sensor data
    while (1)
    {
        // Capture the rising edge event count from Timer 3B
        edge_count = Timer3B_RisingEdgeEvent_Capture();

        // Read and calculate the PWM duty cycle (for controlling the motor or other devices)
        readAndCalculateDutyCycle();
        
        // Read and calculate the current sensor value (taking 500 readings or samples)
        readAndCalculateCurrentSensor(500);
        
        // Check if the RPM (Revolutions Per Minute) is below a certain threshold
        if (rpm < 10400)
        {
            // Display the calculated readings on the LCD
            displayReadings();
            
            // Send the calculated readings over UART for external monitoring or logging
            sendReadingsOverUART();
            
            // Delay for 500 milliseconds before the next update (rate-limiting the process)
            delayMs(500); // Update every 500 ms
        }
    }
}
